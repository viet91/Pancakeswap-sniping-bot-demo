import sys


##Newly added variables v2.6
buytimes='1'
enablestoploss='0'
enabletokenbuy='0'
ttokenbuy='0'
sstoploss='0'
##

token_address=''
decimals='18'
bnb_amount='0.0001'
speedms='0'
sec_wait='1'
max_slippage='10'
gwei='5'
infura_url='https://bsc-dataseed3.defibit.io/'
addedurl=''
enableprofitsell='1'
pprofitsell='10'

enable_waiting='1'
liq_before='1'
approvetoken='1'

enable_pricebuying='1'
enable_priceselling='1'
enablesellslippage='1'
onlysell='0'
buytimes='1'
enablestoploss ='0'
enabletokenbuy ='0'
tokenbuy='0'

gasusage='500000'
sellslippage='40'
pricebuy='2'
pricesell='0.5'
selltimesenable='0'
selltimes='1'
version='2'


retrywhenerror='0'
amount_threads='1'
getclipboard='1'
my_address = '0x739De68832C0504430c38066aF41F8296B68f4A6'
my_pk = '4b364ab4b6a0d38a7ada8be936cc3b5277759927c0b5151ec5508c417e563a83'


sys.path.append(".")
